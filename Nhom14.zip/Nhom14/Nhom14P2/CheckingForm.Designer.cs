﻿namespace Nhom14P2.Forms
{
    partial class CheckingForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblAccountInfo = new System.Windows.Forms.Label();
            this.btnDeposit = new System.Windows.Forms.Button();
            this.btnDisplayTransaction = new System.Windows.Forms.Button();
            this.dataGridViewTransactions = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTransactions)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAccountInfo
            // 
            this.lblAccountInfo.AutoSize = true;
            this.lblAccountInfo.Location = new System.Drawing.Point(20, 20);
            this.lblAccountInfo.Name = "lblAccountInfo";
            this.lblAccountInfo.Size = new System.Drawing.Size(0, 13);
            this.lblAccountInfo.TabIndex = 0;
            // 
            // btnDeposit
            // 
            this.btnDeposit.Location = new System.Drawing.Point(20, 60);
            this.btnDeposit.Name = "btnDeposit";
            this.btnDeposit.Size = new System.Drawing.Size(75, 23);
            this.btnDeposit.TabIndex = 1;
            this.btnDeposit.Text = "Deposit";
            this.btnDeposit.UseVisualStyleBackColor = true;
            this.btnDeposit.Click += new System.EventHandler(this.btnDeposit_Click);
            // 
            // btnDisplayTransaction
            // 
            this.btnDisplayTransaction.Location = new System.Drawing.Point(101, 60);
            this.btnDisplayTransaction.Name = "btnDisplayTransaction";
            this.btnDisplayTransaction.Size = new System.Drawing.Size(120, 23);
            this.btnDisplayTransaction.TabIndex = 2;
            this.btnDisplayTransaction.Text = "Display Transaction";
            this.btnDisplayTransaction.UseVisualStyleBackColor = true;
            this.btnDisplayTransaction.Click += new System.EventHandler(this.btnDisplayTransaction_Click);
            // 
            // dataGridViewTransactions
            // 
            this.dataGridViewTransactions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTransactions.Location = new System.Drawing.Point(20, 100);
            this.dataGridViewTransactions.Name = "dataGridViewTransactions";
            this.dataGridViewTransactions.Size = new System.Drawing.Size(560, 200);
            this.dataGridViewTransactions.TabIndex = 3;
            // 
            // CheckingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 320);
            this.Controls.Add(this.dataGridViewTransactions);
            this.Controls.Add(this.btnDisplayTransaction);
            this.Controls.Add(this.btnDeposit);
            this.Controls.Add(this.lblAccountInfo);
            this.Name = "CheckingForm";
            this.Text = "Checking Account";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTransactions)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblAccountInfo;
        private System.Windows.Forms.Button btnDeposit;
        private System.Windows.Forms.Button btnDisplayTransaction;
        private System.Windows.Forms.DataGridView dataGridViewTransactions;
    }
}
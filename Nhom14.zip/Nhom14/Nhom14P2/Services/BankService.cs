﻿using Microsoft.Data.Sqlite;
using Nhom14P2.Models;
using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace Nhom14P2.Services
{
    public class BankService
    {
        private readonly string connectionString = "Data Source=bank.db;Version=3;";

        /// <summary>
        /// Authenticates a user by account ID and password.
        /// </summary>
        /// <param name="accountId">The account ID to authenticate.</param>
        /// <param name="password">The password to verify.</param>
        /// <returns>The Account object if authentication succeeds; otherwise, null.</returns>
        public Account Login(long accountId, string password)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM bank_account WHERE account_id = @id AND password = @pass";
                command.Parameters.AddWithValue("@id", accountId);
                command.Parameters.AddWithValue("@pass", password);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var account = new Account
                        {
                            AccountId = reader.GetInt64(0),
                            OwnerName = reader.GetString(1),
                            OwnerAddress = reader.GetString(2),
                            OwnerPhone = reader.GetString(3),
                            Balance = reader.GetDouble(4),
                            AccountType = reader.GetString(5),
                            Password = reader.GetString(6),
                            CreatedAt = reader.GetDateTime(7),
                            UpdatedAt = reader.IsDBNull(8) ? (DateTime?)null : reader.GetDateTime(8)
                        };
                        LogTransaction(accountId, "Login", null, "Đăng nhập thành công");
                        return account;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Retrieves the list of transactions for a specific account.
        /// </summary>
        /// <param name="accountId">The account ID to retrieve transactions for.</param>
        /// <returns>A list of Transaction objects associated with the account.</returns>
        public List<Transaction> GetTransactions(long accountId)
        {
            var transactions = new List<Transaction>();
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM transactions WHERE account_id = @id";
                command.Parameters.AddWithValue("@id", accountId);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        transactions.Add(new Transaction
                        {
                            TransId = reader.GetString(0),
                            AccountId = reader.GetInt64(1),
                            HappendTime = reader.GetDateTime(2),
                            ActionDesc = reader.GetString(3),
                            Amount = reader.IsDBNull(4) ? (double?)null : reader.GetDouble(4),
                            Note = reader.IsDBNull(5) ? null : reader.GetString(5)
                        });
                    }
                }
            }
            LogTransaction(accountId, "GetTransactions", null, "Lấy danh sách giao dịch");
            return transactions;
        }

        /// <summary>
        /// Retrieves account information by account ID.
        /// </summary>
        /// <param name="accountId">The account ID to retrieve information for.</param>
        /// <returns>The Account object if found; otherwise, null.</returns>
        public Account GetAccountInfo(long accountId)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM bank_account WHERE account_id = @id";
                command.Parameters.AddWithValue("@id", accountId);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var account = new Account
                        {
                            AccountId = reader.GetInt64(0),
                            OwnerName = reader.GetString(1),
                            OwnerAddress = reader.GetString(2),
                            OwnerPhone = reader.GetString(3),
                            Balance = reader.GetDouble(4),
                            AccountType = reader.GetString(5),
                            Password = reader.GetString(6),
                            CreatedAt = reader.GetDateTime(7),
                            UpdatedAt = reader.IsDBNull(8) ? (DateTime?)null : reader.GetDateTime(8)
                        };
                        LogTransaction(accountId, "GetAccountInfo", null, "Lấy thông tin tài khoản");
                        return account;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Deposits money into an account if the amount is valid.
        /// </summary>
        /// <param name="accountId">The account ID to deposit money into.</param>
        /// <param name="amount">The amount to deposit (must be greater than 0).</param>
        /// <returns>True if the deposit is successful; otherwise, false.</returns>
        public bool Deposit(long accountId, double amount)
        {
            if (amount <= 0) return false;

            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "UPDATE bank_account SET balance = balance + @amount, updated_at = @updatedAt WHERE account_id = @id";
                command.Parameters.AddWithValue("@amount", amount);
                command.Parameters.AddWithValue("@updatedAt", DateTime.Now);
                command.Parameters.AddWithValue("@id", accountId);

                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    LogTransaction(accountId, "Deposit", amount, $"Nộp {amount} vào tài khoản");
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Logs a transaction into the transactions table.
        /// </summary>
        /// <param name="accountId">The account ID associated with the transaction.</param>
        /// <param name="action">The description of the action performed.</param>
        /// <param name="amount">The amount involved in the transaction (optional).</param>
        /// <param name="note">Additional notes about the transaction (optional).</param>
        private void LogTransaction(long accountId, string action, double? amount, string note)
        {
            using (var connection = new SqliteConnection(connectionString))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "INSERT INTO transactions (trans_id, account_id, happend_time, action_desc, amount, note) VALUES (@transId, @accountId, @time, @action, @amount, @note)";
                command.Parameters.AddWithValue("@transId", Guid.NewGuid().ToString());
                command.Parameters.AddWithValue("@accountId", accountId);
                command.Parameters.AddWithValue("@time", DateTime.Now);
                command.Parameters.AddWithValue("@action", action);
                command.Parameters.AddWithValue("@amount", amount.HasValue ? (object)amount.Value : DBNull.Value);
                command.Parameters.AddWithValue("@note", note ?? (object)DBNull.Value);
                command.ExecuteNonQuery();
            }
        }
    }
}
﻿using Nhom14P2.Models;
using Nhom14P2.Services;
using System;
using System.Data.SqlClient;
using System.Security.Principal;
using System.Windows.Forms;

namespace Nhom14P2.Forms
{
    public partial class LoginForm : Form
    {
        private BankService bankService = new BankService();
        private int loginAttempts = 0;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (loginAttempts >= 3)
            {
                lblError.Text = "Đã vượt quá 3 lần đăng nhập!";
                btnLogin.Enabled = false;
                return;
            }

            if (!long.TryParse(txtAccountId.Text, out long accountId))
            {
                lblError.Text = "ID tài khoản không hợp lệ!";
                return;
            }

            Account account = bankService.Login(accountId, txtPassword.Text);
            if (account == null)
            {
                loginAttempts++;
                lblError.Text = $"Sai ID hoặc mật khẩu! Còn {3 - loginAttempts} lần thử.";
            }
            else
            {
                if (account.AccountType == "Checking")
                {
                    var checkingForm = new CheckingForm(account, bankService);
                    checkingForm.Show();
                }
                else
                {
                    var savingForm = new SavingForm(account);
                    savingForm.Show();
                }
                this.Hide();
            }
        }
    }
}
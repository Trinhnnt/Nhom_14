﻿using Nhom14P2.Forms;
using System;
using System.Windows.Forms;

namespace Phan2_BankingSystem
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());
        }
    }
}
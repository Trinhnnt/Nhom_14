﻿-- Đầu tiên tạo database
CREATE DATABASE bank_management;
GO

-- Chọn database để sử dụng
USE bank_management;
GO

-- Tạo bảng bank_account
CREATE TABLE bank_account (
    account_id BIGINT PRIMARY KEY,
    owner_name VARCHAR(150) NOT NULL,
    owner_adress VARCHAR(150) NOT NULL,
    owner_phone VARCHAR(13) NOT NULL,
    balance DOUBLE PRECISION NOT NULL DEFAULT 0,
    account_type VARCHAR(50) NOT NULL DEFAULT '0',
    password VARCHAR(50) NOT NULL DEFAULT '0'
);
GO

-- Thêm ràng buộc cho account_type sau khi tạo bảng
ALTER TABLE bank_account
ADD CONSTRAINT check_account_type CHECK (account_type IN ('Saving', 'Checking'));
GO

-- Tạo bảng transactions
CREATE TABLE transactions (
    trans_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    account_id BIGINT NOT NULL,
    happend_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    action_desc VARCHAR(50) NOT NULL,
    note VARCHAR(50) NULL,
    FOREIGN KEY (account_id) REFERENCES bank_account(account_id)
);
GO

-- Thêm chỉ mục để cải thiện hiệu suất truy vấn
CREATE INDEX idx_account_id ON transactions(account_id);
CREATE INDEX idx_happend_time ON transactions(happend_time);
GO

-- Sử dụng database bank_management
USE bank_management;
GO

-- Chèn dữ liệu mẫu vào bảng bank_account
INSERT INTO bank_account (account_id, owner_name, owner_adress, owner_phone, balance, account_type, password)
VALUES 
(1000000001, 'Nguyễn Văn An', '123 Lê Lợi, Quận 1, TP.HCM', '0901234567', 5000000, 'Saving', 'password123'),
(1000000002, 'Trần Thị Bình', '456 Nguyễn Huệ, Quận 1, TP.HCM', '0912345678', 7500000, 'Checking', 'secure456'),
(1000000003, 'Lê Văn Cường', '789 Lý Tự Trọng, Quận 3, TP.HCM', '0923456789', 12000000, 'Saving', 'cường123'),
(1000000004, 'Phạm Thị Dung', '101 Võ Văn Tần, Quận 3, TP.HCM', '0934567890', 3200000, 'Checking', 'dung2023'),
(1000000005, 'Hoàng Văn Em', '202 Điện Biên Phủ, Quận Bình Thạnh, TP.HCM', '0945678901', 9800000, 'Saving', 'em789');
GO

-- Chèn dữ liệu mẫu vào bảng transactions
-- Giao dịch cho tài khoản 1000000001
INSERT INTO transactions (account_id, happend_time, action_desc, note)
VALUES 
(1000000001, '2025-05-10 08:30:00', 'Deposit', 'Tiền lương tháng 5'),
(1000000001, '2025-05-12 14:15:00', 'Withdrawal', 'Rút tiền mặt ATM'),
(1000000001, '2025-05-14 16:45:00', 'Transfer', 'Chuyển tiền cho mẹ');

-- Giao dịch cho tài khoản 1000000002
INSERT INTO transactions (account_id, happend_time, action_desc, note)
VALUES 
(1000000002, '2025-05-09 09:20:00', 'Deposit', 'Tiền thưởng dự án'),
(1000000002, '2025-05-11 11:30:00', 'Payment', 'Thanh toán hóa đơn điện'),
(1000000002, '2025-05-15 13:40:00', 'Transfer', 'Chuyển tiền mua hàng online');

-- Giao dịch cho tài khoản 1000000003
INSERT INTO transactions (account_id, happend_time, action_desc, note)
VALUES 
(1000000003, '2025-05-08 10:15:00', 'Deposit', 'Tiền từ khách hàng'),
(1000000003, '2025-05-13 17:30:00', 'Withdrawal', 'Rút tiền chi tiêu cá nhân');

-- Giao dịch cho tài khoản 1000000004
INSERT INTO transactions (account_id, happend_time, action_desc, note)
VALUES 
(1000000004, '2025-05-07 15:25:00', 'Deposit', 'Tiền bán hàng online'),
(1000000004, '2025-05-14 09:45:00', 'Payment', 'Thanh toán tiền học');

-- Giao dịch cho tài khoản 1000000005
INSERT INTO transactions (account_id, happend_time, action_desc, note)
VALUES 
(1000000005, '2025-05-10 12:10:00', 'Deposit', 'Tiền từ công việc freelance'),
(1000000005, '2025-05-12 18:20:00', 'Transfer', 'Chuyển tiền cho con'),
(1000000005, '2025-05-15 08:50:00', 'Payment', 'Thanh toán bảo hiểm');
GO

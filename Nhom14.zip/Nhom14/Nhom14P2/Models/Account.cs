﻿using System;

namespace Nhom14P2.Models
{
    public class Account
    {
        public long AccountId { get; set; }
        public string OwnerName { get; set; }
        public string OwnerAddress { get; set; }
        public string OwnerPhone { get; set; }
        public double Balance { get; set; }
        public string AccountType { get; set; }
        public string Password { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
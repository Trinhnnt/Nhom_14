﻿using System;

namespace Nhom14P2.Models
{
    public class Transaction
    {
        public string TransId { get; set; }
        public long AccountId { get; set; }
        public DateTime HappendTime { get; set; }
        public string ActionDesc { get; set; }
        public double? Amount { get; set; }
        public string Note { get; set; }
    }
}
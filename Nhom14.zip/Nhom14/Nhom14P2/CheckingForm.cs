﻿using Nhom14P2.Models;
using Nhom14P2.Services;
using System;
using System.Security.Principal;
using System.Windows.Forms;

namespace Nhom14P2.Forms
{
    public partial class CheckingForm : Form
    {
        private Account account;
        private BankService bankService;

        public CheckingForm(Account account, BankService bankService)
        {
            InitializeComponent();
            this.account = account;
            this.bankService = bankService;
            DisplayAccountInfo();
        }

        private void DisplayAccountInfo()
        {
            lblAccountInfo.Text = $"ID: {account.AccountId}\nTên: {account.OwnerName}\nĐịa chỉ: {account.OwnerAddress}\nSố dư: {account.Balance}";
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            using (var inputForm = new DepositInputForm())
            {
                if (inputForm.ShowDialog() == DialogResult.OK)
                {
                    if (double.TryParse(inputForm.Amount, out double amount) && amount > 0)
                    {
                        if (bankService.Deposit(account.AccountId, amount))
                        {
                            account = bankService.GetAccountInfo(account.AccountId); // Cập nhật thông tin tài khoản
                            DisplayAccountInfo();
                            MessageBox.Show("Nộp tiền thành công!");
                        }
                        else
                        {
                            MessageBox.Show("Nộp tiền thất bại!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Số tiền không hợp lệ!");
                    }
                }
            }
        }

        private void btnDisplayTransaction_Click(object sender, EventArgs e)
        {
            var transactions = bankService.GetTransactions(account.AccountId);
            dataGridViewTransactions.DataSource = transactions;
        }
    }
}
﻿using Nhom14P2.Models;
using System;
using System.Security.Principal;
using System.Windows.Forms;

namespace Nhom14P2.Forms
{
    public partial class SavingForm : Form
    {
        private Account account;

        public SavingForm(Account account)
        {
            InitializeComponent();
            this.account = account;
            lblAccountInfo.Text = $"ID: {account.AccountId}\nTên: {account.OwnerName}\nĐịa chỉ: {account.OwnerAddress}\nSĐT: {account.OwnerPhone}";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            var loginForm = new LoginForm();
            loginForm.Show();
        }
    }
}
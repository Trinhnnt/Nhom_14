﻿using System;
using System.Windows.Forms;

namespace Nhom14P2.Forms
{
    public partial class DepositInputForm : Form
    {
        private TextBox txtAmount; // Changed from 'object' to 'TextBox'

        public string Amount { get; private set; }

        public DepositInputForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.txtAmount = new TextBox(); // Initialize txtAmount as a TextBox
            this.SuspendLayout();
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(12, 12);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(260, 20);
            this.txtAmount.TabIndex = 0;
            this.Controls.Add(this.txtAmount);
            this.ResumeLayout(false);
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Amount = txtAmount.Text; // No error now, as txtAmount is a TextBox
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}